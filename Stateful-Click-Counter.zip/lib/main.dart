import 'package:flutter/material.dart';

void main() => runApp(KisilikAnketiApp());

class KisilikAnketiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kişilik Anketi',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: KisilikAnketiForm(),
    );
  }
}

class KisilikAnketiForm extends StatefulWidget {
  @override
  _KisilikAnketiFormState createState() => _KisilikAnketiFormState();
}

class _KisilikAnketiFormState extends State<KisilikAnketiForm> {
  final _formKey = GlobalKey<FormState>();
  String? _isimSoyisim;
  String? _cinsiyet;
  bool _resitMi = false;
  bool _sigaraKullaniyorMu = false;
  double _sigaraSayisi = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kişilik Anketi'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // Ad ve Soyad
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Adınız ve soyadınız',
                  ),
                  onSaved: (value) {
                    _isimSoyisim = value;
                  },
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Lütfen adınızı ve soyadınızı girin';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 16.0),

                // Cinsiyet seçimi
                DropdownButtonFormField<String>(
                  decoration:
                      InputDecoration(labelText: 'Cinsiyetinizi Seçiniz'),
                  items: ['Erkek', 'Kadın', 'Diğer'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _cinsiyet = newValue;
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Lütfen cinsiyet seçiniz';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 16.0),

                // Reşit misiniz? (Checkbox)
                CheckboxListTile(
                  title: Text('Reşit misiniz?'),
                  value: _resitMi,
                  onChanged: (bool? value) {
                    setState(() {
                      _resitMi = value ?? false;
                    });
                  },
                ),
                SizedBox(height: 16.0),

                // Sigara Kullanımı (Switch)
                SwitchListTile(
                  title: Text('Sigara kullanıyor musunuz?'),
                  value: _sigaraKullaniyorMu,
                  onChanged: (bool value) {
                    setState(() {
                      _sigaraKullaniyorMu = value;
                    });
                  },
                ),

                // Slider (Eğer sigara içiyorsa)
                if (_sigaraKullaniyorMu) ...[
                  Text('Günde kaç sigara içiyorsunuz?'),
                  Slider(
                    value: _sigaraSayisi,
                    min: 0,
                    max: 40,
                    divisions: 40,
                    label: _sigaraSayisi.round().toString(),
                    onChanged: (double value) {
                      setState(() {
                        _sigaraSayisi = value;
                      });
                    },
                  ),
                ],

                SizedBox(height: 32.0),

                // Gönder Butonu
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();

                        // Navigator ile Sonuç Sayfasına Yönlendirme
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SonucSayfasi(
                              isimSoyisim: _isimSoyisim!,
                              cinsiyet: _cinsiyet!,
                              resitMi: _resitMi,
                              sigaraKullaniyorMu: _sigaraKullaniyorMu,
                              sigaraSayisi: _sigaraKullaniyorMu
                                  ? _sigaraSayisi.round()
                                  : 0,
                            ),
                          ),
                        );
                      }
                    },
                    child: Text('Bilgilerimi gönder'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SonucSayfasi extends StatelessWidget {
  final String isimSoyisim;
  final String cinsiyet;
  final bool resitMi;
  final bool sigaraKullaniyorMu;
  final int sigaraSayisi;

  SonucSayfasi({
    required this.isimSoyisim,
    required this.cinsiyet,
    required this.resitMi,
    required this.sigaraKullaniyorMu,
    required this.sigaraSayisi,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Anket Sonuçları'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Ad ve Soyad: $isimSoyisim', style: TextStyle(fontSize: 20)),
            SizedBox(height: 8.0),
            Text('Cinsiyet: $cinsiyet', style: TextStyle(fontSize: 20)),
            SizedBox(height: 8.0),
            Text('Reşit misiniz: ${resitMi ? 'Evet' : 'Hayır'}',
                style: TextStyle(fontSize: 20)),
            SizedBox(height: 8.0),
            Text(
                'Sigara kullanıyor musunuz: ${sigaraKullaniyorMu ? 'Evet' : 'Hayır'}',
                style: TextStyle(fontSize: 20)),
            if (sigaraKullaniyorMu)
              Text('Günde içilen sigara sayısı: $sigaraSayisi',
                  style: TextStyle(fontSize: 20)),
            SizedBox(height: 32.0),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context); // Anasayfaya geri dönmek için
                },
                child: Text('Anasayfaya dön'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
