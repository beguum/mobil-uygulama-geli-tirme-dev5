package com.example.statefulclickcounter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
